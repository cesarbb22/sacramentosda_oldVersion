@extends('layouts.masterPageAdmin')

@section('content')

<h1>Pagina de prueba</h1>
@endsection