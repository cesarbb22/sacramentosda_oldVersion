<?php $__env->startSection('content'); ?>

<style type="text/css">
#n {
  padding-top:5px;
}

</style>

<div id='n' class="row">
    <div class="col s12 m4 l2"></div>
    <div class=" col s12 m4 l8 card-panel z-depth-5">

        <div class="row">
          <div class="col s12 m4 l4"></div>
          
          <div class="col s12 m4 l4"><h4 class="center-align">Solicitud Eliminar</h4></div>
          
          <div class="col s12 m4 l4"></div>
        </div>
        
        <?php if(count($errors) > 0): ?>
    
    <div class="row">
      <div class="col s12">
        <div class="card-panel red">
          <ul class='white-text'>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
      </div>
    </div>
<?php endif; ?>

<form id="formSolicitudEli" method="POST" action="/crearSolicitudEliminar">
          <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="input-field col s4">
                 <input id="nombre" name='nombre' type="text" class="validate" required>
                  <label for="nombree">Nombre completo del solicitante:</label>
                 </div>
                 
                <div class="input-field col s3">
                 <select name="parroquia" id="parroquias">
                     <option value="">---</option>
                  <?php $__currentLoopData = $parroquias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pa->IDParroquia); ?>"><?php echo e($pa->NombreParroquia); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select>
                     <label>Seleccione la Parroquia:</label>
                </div>
                
       </div>
            
            <div class="row">
                <div class="input-field col s8">
                  <input id="email" name='email' type="text" class="validate" required>
                  <label for="emaill">Correo Electrónico :</label>
                </div>
            </div>
                 
            <div class="row">
                <div class="input-field col s12">
                  <textarea id="descripcion" name="descripcion" class="materialize-textarea"></textarea>
                  <label for="descripcion">Motivo para solicitar eliminar acta:</label>
                </div>
           </div>
        <div class="row"></br></br></div>
        <div class="row">
                <input id="guardarActa" class="waves-effect waves-light btn right" type="submit" value="Guardar"/>
            </div>
               
    </form>
     </div>
     <div class="col s12 m4 l2"></div>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>