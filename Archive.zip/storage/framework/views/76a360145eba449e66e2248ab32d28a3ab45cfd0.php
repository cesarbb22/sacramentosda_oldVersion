<?php $__env->startSection('content'); ?>

<div id='n' class="row">
    <div class="col s12 m4 l2"></div>
    <div class=" col s12 m4 l8 card-panel z-depth-5">

        <div class="row">
          <div class="col s12 m4 l4"></div>
          
          <div class="col s12 m4 l4"><h4 class="center-align">Editar Acta</h4></div>
          
          <div class="col s12 m4 l4"></div>
        </div>
        
        <?php if(count($errors) > 0): ?>
    
    <div class="row">
      <div class="col s12">
        <div class="card-panel red">
          <ul class='white-text'>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
      </div>
    </div>
<?php endif; ?>
        
        <form method="POST" action="/actualizarActa">
            
          <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="input-field col s6">
                  <input id="numCedulaEdit" name='numCedulaEdit' type="text" class="validate" value="<?php echo e($persona->Cedula); ?>"  maxlength="9">
                  <label for="numCedulaEdit">Número de cédula:</label>
                </div>
                


            </div>
            <div class="row">
                <div class="input-field col s4">
                  <input id="nombreEdit" name='nombreEdit' type="text" class="validate" value="<?php echo e($persona->Nombre); ?>">
                  <label for="nombreEdit">Nombre:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido1Edit" name='apellido1Edit' type="text" class="validate" value="<?php echo e($persona->PrimerApellido); ?>">
                  <label for="apellido1Edit">Primer apellido:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido2Edit" name='apellido2Edit' type="text" class="validate" value="<?php echo e($persona->SegundoApellido); ?>">
                  <label for="apellido2Edit">Segundo apellido:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s4">
                    <p>
                      <input name='tipoHijo' type="radio" id="tipoH1" value="1" />
                      <label for="tipoH1">Hijo Natural</label>
                    </p>
                    <p>
                      <input name='tipoHijo' type="radio" id="tipoH2" value="2" />
                      <label for="tipoH2">Hijo Legítimo</label>
                    </p>
                </div>
                <div class="col s8">
                  <div class="row">
                    <div class="input-field col s12">
                      <input id="nombreMadreEdit" name='nombreMadreEdit' type="text" class="validate" value="<?php echo e($laico->NombreMadre); ?>">
                      <label for="nombreMadreEdit">Nombre completo de la madre:</label>
                    </div>
                  </div>
                  <div class="row">
                    <div class="input-field col s12">
                      <input id="nombrePadreEdit" name='nombrePadreEdit' type="text" class="validate" value="<?php echo e($laico->NombrePadre); ?>">
                      <label for="nombrePadreEdit">Nombre completo del padre:</label>
                    </div>
                  </div>
                </div>
            </div>
            <div class="row">
              <div class="input-field col s6">
                </div>
                <div class="input-field col s6">
                  <label>Fecha de nacimiento:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                  <input id="lugarNacEdit" name='lugarNacEdit' type="text" class="validate" value="<?php echo e($laico->LugarNacimiento); ?>">
                  <label for="LugarNacEdit">Lugar de nacimiento:</label>
                </div>
                 <div class="input-field col s6">
                  <input id="fechaNacEdit" name='fechaNacEdit' pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($laico->FechaNacimiento); ?>">
                </div>
            </div>
            
          <div class="row">
            <div class="input-field col s12">
            <input id="notasMarginalesEdit" name='notasMarginalesEdit' type="text" class="validate" value="<?php echo e($acta->NotasMarginales); ?>">
            <label for="notasMarginalesEdit">Notas Marginales:</label>
            </div>
          </div>
          
          
          
          <div class="row"></div>
        
        <div class="row">
            
            <ul class="collapsible" data-collapsible="accordion">
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Bautismo</div>
                  <div class="collapsible-body">
                        
                        <div class="row">
              <div class="input-field col s6">
                </div>
                <div class="input-field col s6">
                  <label>Fecha de Bautismo:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                  <input id="lugarBautizo" name="lugarBautizo" type="text" class="validate" value="<?php echo e($actaBautismo->LugarBautismo); ?>">
                  <label for="lugarBautizo"> Bautizado en:</label>
                </div>
                 <div class="input-field col s6">
                  <input id="fechaBaut" name="fechaBautizo" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaBautismo->FechaBautismo); ?>">
                </div>
                
            </div>
            
            <div class="row">
              <div class="input-field col s8">
                  <input id="nombreMadrina" name="nombreMadrinaB" type="text" class="validate" value="<?php echo e($actaBautismo->PadrinoBau1); ?>">
                  <label for="nombreMadrina">Nombre completo de la madrina:</label>
                </div>
                <div class="input-field col s8">
                  <input id="nombrePadrino" name="nombrePadrinoB" type="text" class="validate" value="<?php echo e($actaBautismo->PadrinoBau2); ?>">
                  <label for="nombrePadrino">Nombre completo del padrino:</label>
                </div>
                  <div class="input-field col s8">
                <label for="informacion">Esta Información consta en:</label>
                </div>
            </div>
            
            <div class="row">
             
                <div class="input-num col s4">
                  <input id="numLibroB" name="numLibroB" type="number" class="validate" value="<?php echo e($UbicacionActaBautismo->Libro); ?>">
                  <label for="numLibroB">Número de Libro:</label>
                </div>
                <div class="input-num col s4">
                  <input id="numFolioB" name="numFolioB" type="number" class="validate" value="<?php echo e($UbicacionActaBautismo->Folio); ?>">
                  <label for="numFolioB">Número de Folio:</label>
                </div>
                   <div class="input-num col s4">
                  <input id="numAsientoB" name="numAsientoB" type="number" class="validate" value="<?php echo e($UbicacionActaBautismo->Asiento); ?>">
                  <label for="numAsientoB">Número de Asiento:</label>
                </div>
                
                      
                  </div>
                </li>
                
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Confirma</div>
                  <div class="collapsible-body">
                    
                        <div class="row">
              <div class="input-field col s6">
                </div>
                <div class="input-field col s6">
                  <label>Fecha de Confirma:</label>
                </div>
            </div>
          <div class="row">
          <div class="input-field col s6">
            <input id="lugarConfirma" name="lugarConfirma" type="text" class="validate" value="<?php echo e($actaConfirma -> LugarConfirma); ?>">
            <label for="lugarConfirma"> Confirmado en:</label>
          </div>
           <div class="input-field col s6">
            <input id="fechaConfir" name="fechaConfirma" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaConfirma -> FechaConfirma); ?>">
          </div>
          </div>
                        
            <div class="row">
                <div class="input-field col s8">
                  <input id="nombrePadrino1" name="nombrePadrinoC1" type="text" class="validate" value="<?php echo e($actaConfirma -> PadrinoCon1); ?>">
                  <label for="nombrePadrino1">Nombre completo del padrino o madrina:</label>
                </div>
                  <div class="input-field col s8">
                  <input id="nombrePadrino2" name="nombrePadrinoC2" type="text" class="validate" value="<?php echo e($actaConfirma -> PadrinoCon2); ?>">
                  <label for="nombrePadrino2">Nombre completo del padrino o madrina:</label>
                </div>
                  <div class="input-field col s8">
                <label for="informacion">Esta Información consta en:</label>
                </div>
            </div>
                          
            <div class="row">
             
                <div class="input-num col s4">
                  <input id="numLibroC" name="numLibroC" type="number" class="validate" value="<?php echo e($UbicacionActaConfirma->Libro); ?>">
                  <label for="numLibroC">Número de Libro:</label>
                </div>
                <div class="input-num col s4">
                  <input id="numFolioC" name="numFolioC" type="number" class="validate" value="<?php echo e($UbicacionActaConfirma->Folio); ?>">
                  <label for="numFolioC">Número de Folio:</label>
                </div>
                   <div class="input-num col s4">
                  <input id="numAsientoC" name="numAsientoC" type="number" class="validate" value="<?php echo e($UbicacionActaConfirma->Asiento); ?>">
                  <label for="numAsientoC">Número de Asiento:</label>
                </div>
                
                  
                  </div>
                </li>
                
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Matrimonio</div>
                  <div class="collapsible-body">
                   
                        <div class="row">
              <div class="input-field col s6">
                </div>
                <div class="input-field col s6">
                  <label>Fecha del Matrimonio:</label>
                </div>
            </div>
          <div class="row">
          <div class="input-field col s6">
            <input id="lugarMatrimonio" name="lugarMatrimonio" type="text" class="validate" value="<?php echo e($actaMatrimonio -> LugarMatrimonio); ?>">
            <label for="lugarMatrimonio"> Matrimonio en:</label>
          </div>
           <div class="input-field col s6">
            <input id="fechaMatrimonio" name="fechaMatrimonio" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaMatrimonio -> FechaMatrimonio); ?>">
          </div>
          </div>
                        
            <div class="row">
                <div class="input-field col s8">
                  <input id="nombreConyuge" name="nombreConyuge" type="text" class="validate" value="<?php echo e($actaMatrimonio -> NombreConyugue); ?>">
                  <label for="nombreConyuge">Nombre completo del cónyuge:</label>
                </div>
                  <div class="input-field col s8">
                <label for="informacion">Esta Información consta en:</label>
                </div>
            </div>
                          
            <div class="row">
             
                <div class="input-num col s4">
                  <input id="numLibroM" name="numLibroM" type="number" class="validate" value="<?php echo e($UbicacionActaMatrimonio->Libro); ?>">
                  <label for="numLibroM">Número de Libro:</label>
                </div>
                <div class="input-num col s4">
                  <input id="numFolioM" name="numFolioM" type="number" class="validate" value="<?php echo e($UbicacionActaMatrimonio->Folio); ?>">
                  <label for="numFolioM">Número de Folio:</label>
                </div>
                   <div class="input-num col s4">
                  <input id="numAsientoM" name="numAsientoM" type="number" class="validate" value="<?php echo e($UbicacionActaMatrimonio->Asiento); ?>">
                  <label for="numAsientoM">Número de Asiento:</label>
                </div>
                
                  </div>
                </li>
                
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Defunción</div>
                  <div class="collapsible-body">
                    
                        <div class="row">
              <div class="input-field col s6">
                </div>
                <div class="input-field col s6">
                  <label>Fecha de la defunción :</label>
                </div>
            </div>
          <div class="row">
          <div class="input-field col s6">
            <input id="lugarDefuncion" name="lugarDefuncion" type="text" class="validate" value="<?php echo e($actaDefuncion -> LugarDefuncion); ?>">
            <label for="lugarDefuncion"> Defunción en:</label>
          </div>
           <div class="input-field col s6">
            <input id="fechaDefuncion" name="fechaDefuncion" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaDefuncion -> FechaDefuncion); ?>">
          </div>
          </div>
                        
            <div class="row">
                <div class="input-field col s8">
                  <input id="causaDefuncion" name="causaDefuncion" type="text" class="validate" value="<?php echo e($actaDefuncion -> CausaMuerte); ?>">
                  <label for="causaDefuncion">Causa de la muerte:</label>
                </div>
                  <div class="input-field col s8">
                <label for="informacion">Esta Información consta en:</label>
                </div>
            </div>
                          
            <div class="row">
             
                <div class="input-num col s4">
                  <input id="numLibroD" name="numLibroD" type="number" class="validate" value="<?php echo e($UbicacionActaDefuncion->Libro); ?>">
                  <label for="numLibroD">Número de Libro:</label>
                </div>
                <div class="input-num col s4">
                  <input id="numFolioD" name="numFolioD" type="number" class="validate" value="<?php echo e($UbicacionActaDefuncion->Folio); ?>">
                  <label for="numFolioD">Número de Folio:</label>
                </div>
                   <div class="input-num col s4">
                  <input id="numAsientoD" name="numAsientoD" type="number" class="validate" value="<?php echo e($UbicacionActaDefuncion->Asiento); ?>">
                  <label for="numAsientoD">Número de Asiento:</label>
                </div>
                
            </div>
            
                  </div>
                </li>
            </ul>
            
        </div>
          
          
          
          

        <div class="row"></br></br></div>

        
        <div class="row">
                <input id="guardarActa" class="waves-effect waves-light btn right" type="submit" value="Guardar"/>
                <!-- <a href="<?php echo e(route('/actualizar', $persona->IDPersona)); ?>" class="waves-effect waves-light btn right">
                        Guardar
                        </a> -->
        </div>
        
        <input type="hidden" name="IDPersona" id="IDPersona" value= "<?php echo e($persona->IDPersona); ?>" />
        
        </form>
        
    </div>
    <div class="col s12 m4 l2"></div>
</div>

<script>

window.onload = function() {
    
	  $('#tipoH1').prop('checked', true);
  
 ///////////////////////////////////////////
    $("#tipoH2").change(function() {  
        if($("#tipoH2").is(':checked')) {  
            $("#nombrePadreEdit").prop('disabled', false); 
            $("#nombreMadreEdit").prop('disabled', false);
        }  
    });
    
    
    $("#tipoH1").change(function() {  
        if($("#tipoH1").is(':checked')) {  
            $("#nombrePadreEdit").prop('disabled', true);
            $("#nombreMadreEdit").prop('disabled', false);
        }  
    });

}

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>