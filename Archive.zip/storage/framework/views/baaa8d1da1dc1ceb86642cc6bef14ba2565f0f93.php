<?php $__env->startSection('content'); ?>


<div class="row">
<br>

<?php if(Session::has('errorEmail')): ?>
            <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel red lighten-2 center-align">
              <span class="white-text"><?php echo e(Session::get('errorEmail')); ?></span>
            </div>
          </div>
          <div class="col 10"></div>
    <?php endif; ?>
    
<?php if(Session::has('errorRegister')): ?>
            <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel red lighten-2 center-align">
              <span class="white-text"><?php echo e(Session::get('errorRegister')); ?></span>
            </div>
          </div>
          <div class="col l2"></div>
    <?php endif; ?>

      <div class="col m2 l3"></div>
      <div class="col s12 m8 l6">
        <div class="card-panel z-depth-4">
            
            <h3 class="center-align">Registrarse</h3>
          <br>
          <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Nombre   *</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Primer Apellido *</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="pApellido" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Segundo Apellido *</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="sApellido" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="input-field">
                  <select name='parroquia'>
                    <?php $__currentLoopData = $parroquias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($pa->IDParroquia); ?>"><?php echo e($pa->NombreParroquia); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <label>Seleccione la Parroquia:</label>
                </div>
                
                <div class="input-field">
                  <select name='puesto'>
                    <?php $__currentLoopData = $puesto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($pu->IDPuesto); ?>"><?php echo e($pu->NombrePuesto); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <label>Seleccione su puesto:</label>
                </div>
                
                <div class="input-field">
                  <select name='rol'>
                    <?php $__currentLoopData = $rol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($ro->IDRol); ?>"><?php echo e($ro->NombreRol); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <label>Seleccione su rol:</label>
                </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">Correo electrónico *</label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="cel" class="col-md-4 control-label">Número de celular:</label>

                            <div class="col-md-6">
                                <input id="cel" type="text" class="form-control" name="numCel">
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Contraseña *</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirmar contraseña *</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>
                        </br>
                        <div class=row>
                        
                        <div class="form-group">
                            <div class="col l8">
                                <button id ='btnFake' type="button" class="waves-effect waves-light btn">
                                    Registrar
                                </button>
                                <button id ='btnForm' type="submit" hidden>
                                    
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="" class="col l4 control-label">* Campos obligatorios</label>
                        </div>
                        
                        </div>
                    </form>
          
        </div>
      </div>
      <div class="col m2 l3"></div>
</div>

<script>
  
  window.onload = function() {
    $('select').material_select();
    
    
    $("#btnFake").click(function(){
        var pass1 = $('#password').val();
        var pass2 = $('#password-confirm').val();
          
        if (pass1 == pass2) {
            $("#btnForm").click();
        } else {
            Materialize.toast('Las contraseñas deben coincidir!', 5000) // 4000 is the duration of the toast
        }
    });
    

}
  
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>