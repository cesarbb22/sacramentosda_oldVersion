<?php $__env->startSection('content'); ?>
<div id='n' class="row">
    <?php if(session()->has('msjMalo')): ?>
        <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel red lighten-2 center-align">
              <span class="white-text"><?php echo e(session('msjMalo')); ?></span>
            </div>
          </div>
          <div class="col l2"></div><br><br><br><br><br>
    <?php endif; ?>
    
    <?php if(session()->has('msjBueno')): ?>
        <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel green darken-3 center-align">
              <span class="white-text"><?php echo e(session('msjBueno')); ?></span>
            </div>
          </div>
          <div class="col l2"></div><br><br><br><br><br>
    <?php endif; ?>
    
    <div class="col s12 m4 l2"></div>
    <div class=" col s12 m4 l8 card-panel z-depth-5">

        <div class="row">
          <div class="col s12 m4 l4"></div>
          <div class="col s12 m4 l4"><h4 class="center-align">Detalle de Acta</h4></div>
          <div class="col s12 m4 l4"></div>
        </div>
        
      <?php if(count($errors) > 0): ?>
        <div class="row">
          <div class="col s12">
            <div class="card-panel red">
              <ul class='white-text'>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      <?php endif; ?>
      
      <form method="POST" role='form' action="<?php echo e(url('/pdf')); ?>">
            
          <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="input-field col s6">
                  <input id="numCedulaEdit" name='numCedulaEdit' type="text"  value="<?php echo e($persona->Cedula); ?>"  readonly=”readonly”  maxlength="9">
                  <label for="numCedulaEdit">Número de cédula:</label>
                </div>
                
                <div class="input-field col s6">
                  <input id="parroquia" name='parroquia' type="text"  value="<?php echo e($parroquia->NombreParroquia); ?>"  readonly=”readonly” >
                  <label for="parroquia">Parroquia:</label>
                </div>
            </div>
            
            <div class="row">
                <div class="input-field col s4">
                  <input id="nombreEdit" name='nombreEdit' type="text"  value="<?php echo e($persona->Nombre); ?>" readonly=”readonly” >
                  <label for="nombreEdit">Nombre:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido1Edit" name='apellido1Edit' type="text" value="<?php echo e($persona->PrimerApellido); ?>" readonly=”readonly” >
                  <label for="apellido1Edit">Primer apellido:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido2Edit" name='apellido2Edit' type="text"  value="<?php echo e($persona->SegundoApellido); ?>"readonly=”readonly” >
                  <label for="apellido2Edit">Segundo apellido:</label>
                </div>
            </div>
            
            <div class="row">
                <div class="input-field col s4">
                      <input name='tipoHijo' type="text" id="tipoH1" value="<?php echo e($tipoHijo); ?>" readonly=”readonly” />
                      <label for="tipoH1">Tipo hijo:</label>
                </div>
                <div class="col s8">
                  <div class="row">
                    <div class="input-field col s12">
                      <input id="nombreMadreEdit" name='nombreMadreEdit' type="text"  value="<?php echo e($laico->NombreMadre); ?> "  readonly=”readonly”>
                      <label for="nombreMadreEdit">Nombre completo de la madre:</label>
                    </div>
                  </div>
                  <div class="row">
                    <div class="input-field col s12">
                      <input id="nombrePadreEdit" name='nombrePadreEdit' type="text"  value="<?php echo e($laico->NombrePadre); ?>" readonly=”readonly” >
                      <label for="nombrePadreEdit">Nombre completo del padre:</label>
                    </div>
                  </div>
                </div>
            </div>
            
            <div class="row">
              <div class="input-field col s6"></div>
                <div class="input-field col s6">
                  <label>Fecha de nacimiento:</label>
                </div>
            </div>
            
            <div class="row">
                <div class="input-field col s6">
                  <input id="lugarNacEdit" name='lugarNacEdit' type="text" value="<?php echo e($laico->LugarNacimiento); ?>"readonly=”readonly” >
                  <label for="LugarNacEdit">Lugar de nacimiento:</label>
                </div>
                 <div class="input-field col s6">
                  <input id="fechaNacEdit" name='fechaNacEdit' pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($laico->FechaNacimiento); ?>"readonly=”readonly” >
                </div>
            </div>
            
          <div class="row">
            <div class="input-field col s12">
              <input id="notasMarginalesEdit" name='notasMarginalesEdit' type="text" value="<?php echo e($acta->NotasMarginales); ?>" readonly=”readonly” >
              <label for="notasMarginalesEdit">Notas Marginales:</label>
            </div>
          </div>
          
           <div class="row"></div>
        
        <div class="row">
            
                <div class="collapsible-header waves-light waves-effect white-text">Acta de Bautismo</div>
               
                    <?php if($actaBautismo != null): ?>
                      
                    <div class="row">
                        <div class="input-field col s6"></div>
                        <div class="input-field col s6">
                          <label>Fecha de Bautismo:</label>
                        </div>
                    </div>
                  
                    <div class="row">
                        <div class="input-field col s6">
                          <input id="lugarBautizo" name="lugarBautizo" type="text"  value="<?php echo e($actaBautismo->LugarBautismo); ?>" readonly=”readonly”>
                          <label for="lugarBautizo"> Bautizado en:</label>
                        </div>
                        <div class="input-field col s6">
                          <input id="fechaBaut" name="fechaBautizo" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaBautismo->FechaBautismo); ?>" readonly=”readonly”>
                        </div>
                    </div>
                  
                    <div class="row">
                        <div class="input-field col s8">
                          <input id="nombreMadrina" name="nombreMadrinaB" type="text"  value="<?php echo e($actaBautismo->PadrinoBau1); ?>" readonly=”readonly”>
                          <label for="nombreMadrina">Nombre completo de la madrina:</label>
                        </div>
                        <div class="input-field col s8">
                          <input id="nombrePadrino" name="nombrePadrinoB" type="text"  value="<?php echo e($actaBautismo->PadrinoBau2); ?>" readonly=”readonly”>
                          <label for="nombrePadrino">Nombre completo del padrino:</label>
                        </div>
                        <div class="input-field col s8">
                          <label for="informacion">Esta Información consta en:</label>
                        </div>
                    </div>
                  
                    <div class="row">
                        <div class="input-num col s4">
                          <input id="numLibroB" name="numLibroB" type="number" value="<?php echo e($UbicacionActaBautismo->Libro); ?>" readonly=”readonly”>
                          <label for="numLibroB">Número de Libro:</label>
                        </div>
                        <div class="input-num col s4">
                          <input id="numFolioB" name="numFolioB" type="number"  value="<?php echo e($UbicacionActaBautismo->Folio); ?>" readonly=”readonly”>
                          <label for="numFolioB">Número de Folio:</label>
                        </div>
                        <div class="input-num col s4">
                          <input id="numAsientoB" name="numAsientoB" type="number" value="<?php echo e($UbicacionActaBautismo->Asiento); ?>" readonly=”readonly”>
                          <label for="numAsientoB">Número de Asiento:</label>
                        </div>
                    </div>
                  <?php else: ?>
                          <div class="row">
                      <div class="input-field col s6">
                        <p>No cuenta con esta acta</p>
                      </div>
                    
                    </div>
                    
                       </div>
                  <?php endif; ?>
              
    
                  <div class="collapsible-header waves-light waves-effect white-text">Acta de Confirma</div>
                  
                  <?php if($actaConfirma != null): ?>
                    <div class="row">
                      <div class="input-field col s6"></div>
                      <div class="input-field col s6">
                        <label>Fecha de Confirma:</label>
                      </div>
                    </div>
                
                    <div class="row">
                      <div class="input-field col s6">
                        <input id="lugarConfirma" name="lugarConfirma" type="text"  value="<?php echo e($actaConfirma -> LugarConfirma); ?>" readonly=”readonly”>
                        <label for="lugarConfirma"> Confirmado en:</label>
                      </div>
                      <div class="input-field col s6">
                        <input id="fechaConfir" name="fechaConfirma" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaConfirma -> FechaConfirma); ?>" readonly=”readonly”>
                      </div>
                    </div>
                                
                    <div class="row">
                        <div class="input-field col s8">
                          <input id="nombrePadrino1" name="nombrePadrinoC1" type="text"  value="<?php echo e($actaConfirma -> PadrinoCon1); ?>" readonly=”readonly”>
                          <label for="nombrePadrino1">Nombre completo del padrino o madrina:</label>
                        </div>
                        <div class="input-field col s8">
                          <input id="nombrePadrino2" name="nombrePadrinoC2" type="text"  value="<?php echo e($actaConfirma -> PadrinoCon2); ?>" readonly=”readonly”>
                          <label for="nombrePadrino2">Nombre completo del padrino o madrina:</label>
                        </div>
                        <div class="input-field col s8">
                          <label for="informacion">Esta Información consta en:</label>
                        </div>
                    </div>
                                  
                    <div class="row">
                        <div class="input-num col s4">
                          <input id="numLibroC" name="numLibroC" type="number"  value="<?php echo e($UbicacionActaConfirma->Libro); ?>" readonly=”readonly”>
                          <label for="numLibroC">Número de Libro:</label>
                        </div>
                        <div class="input-num col s4">
                          <input id="numFolioC" name="numFolioC" type="number"  value="<?php echo e($UbicacionActaConfirma->Folio); ?>" readonly=”readonly”>
                          <label for="numFolioC">Número de Folio:</label>
                        </div>
                        <div class="input-num col s4">
                          <input id="numAsientoC" name="numAsientoC" type="number"  value="<?php echo e($UbicacionActaConfirma->Asiento); ?>" readonly=”readonly”>
                          <label for="numAsientoC">Número de Asiento:</label>
                        </div>
                    </div>
                  <?php else: ?>
                    <div class="row">
                      <div class="input-field col s6">
                        <p>No cuenta con esta acta</p>
                      </div>
                      
                    </div>
                    
                <?php endif; ?>
                

                  
                  <div class="collapsible-header waves-light waves-effect white-text">Acta de Matrimonio</div>
                  
                  <?php if($actaMatrimonio != null): ?>
                    <div class="row">
                      <div class="input-field col s6"></div>
                      <div class="input-field col s6">
                        <label>Fecha del Matrimonio:</label>
                      </div>
                    </div>
                  
                    <div class="row">
                      <div class="input-field col s6">
                        <input id="lugarMatrimonio" name="lugarMatrimonio" type="text"  value="<?php echo e($actaMatrimonio -> LugarMatrimonio); ?>" readonly=”readonly”>
                        <label for="lugarMatrimonio"> Matrimonio en:</label>
                      </div>
                      <div class="input-field col s6">
                        <input id="fechaMatrimonio" name="fechaMatrimonio" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaMatrimonio -> FechaMatrimonio); ?>" readonly=”readonly”>
                      </div>
                    </div>
                              
                    <div class="row">
                      <div class="input-field col s8">
                        <input id="nombreConyuge" name="nombreConyuge" type="text"  value="<?php echo e($actaMatrimonio -> NombreConyugue); ?>" readonly=”readonly”>
                        <label for="nombreConyuge">Nombre completo del cónyuge:</label>
                      </div>
                      <div class="input-field col s8">
                        <label for="informacion">Esta Información consta en:</label>
                      </div>
                    </div>
                                
                    <div class="row">
                      <div class="input-num col s4">
                        <input id="numLibroM" name="numLibroM" type="number"  value="<?php echo e($UbicacionActaMatrimonio->Libro); ?>" readonly=”readonly”>
                        <label for="numLibroM">Número de Libro:</label>
                      </div>
                      <div class="input-num col s4">
                        <input id="numFolioM" name="numFolioM" type="number"  value="<?php echo e($UbicacionActaMatrimonio->Folio); ?>" readonly=”readonly”>
                        <label for="numFolioM">Número de Folio:</label>
                      </div>
                      <div class="input-num col s4">
                        <input id="numAsientoM" name="numAsientoM" type="number" value="<?php echo e($UbicacionActaMatrimonio->Asiento); ?>" readonly=”readonly”>
                        <label for="numAsientoM">Número de Asiento:</label>
                      </div>
                    </div>
                  
                <?php else: ?>
                 <div class="row">
                      <div class="input-field col s6">
                        <p>No cuenta con esta acta</p>
                      </div>
                      
                  </div>
                    
                <?php endif; ?>
                
            
                <div class="collapsible-header waves-light waves-effect white-text">Acta de Defunción</div>
            
                  <?php if($actaDefuncion != null): ?>
                    <div class="row">
                      <div class="input-field col s6"></div>
                      <div class="input-field col s6">
                        <label>Fecha de la defunción:</label>
                      </div>
                    </div>
                  
                    <div class="row">
                      <div class="input-field col s6">
                        <input id="lugarDefuncion" name="lugarDefuncion" type="text"  value="<?php echo e($actaDefuncion -> LugarDefuncion); ?>" readonly=”readonly”>
                        <label for="lugarDefuncion"> Defunción en:</label>
                      </div>
                      <div class="input-field col s6">
                        <input id="fechaDefuncion" name="fechaDefuncion" pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d" class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa" value="<?php echo e($actaDefuncion -> FechaDefuncion); ?>" readonly=”readonly”>
                      </div>
                    </div>
                              
                    <div class="row">
                        <div class="input-field col s8">
                          <input id="causaDefuncion" name="causaDefuncion" type="text"  value="<?php echo e($actaDefuncion -> CausaMuerte); ?>" readonly=”readonly”>
                          <label for="causaDefuncion">Causa de la muerte:</label>
                        </div>
                        <div class="input-field col s8">
                          <label for="informacion">Esta Información consta en:</label>
                        </div>
                    </div>
                                
                    <div class="row">
                      <div class="input-num col s4">
                        <input id="numLibroD" name="numLibroD" type="number"  value="<?php echo e($UbicacionActaDefuncion->Libro); ?>" readonly=”readonly”>
                        <label for="numLibroD">Número de Libro:</label>
                      </div>
                      <div class="input-num col s4">
                        <input id="numFolioD" name="numFolioD" type="number"  value="<?php echo e($UbicacionActaDefuncion->Folio); ?>" readonly=”readonly”>
                        <label for="numFolioD">Número de Folio:</label>
                      </div>
                      <div class="input-num col s4">
                          <input id="numAsientoD" name="numAsientoD" type="number"  value="<?php echo e($UbicacionActaDefuncion->Asiento); ?>" readonly=”readonly”>
                          <label for="numAsientoD">Número de Asiento:</label>
                      </div>
                  </div>
                </div>
                
                <?php else: ?>
                 <div class="row">
                      <div class="input-field col s6">
                        <p>No cuenta con esta acta</p>
                      </div>
                   
                  </div>
                <?php endif; ?>
        

        <div class="row"></br></br></div>
        
        <div class="row">
            <button id="Descargar" class="waves-effect waves-light btn right" type="submit"><i class="material-icons left">file_download</i>Descargar PDF</button>
        </div>
    
        <input type="hidden" name="IDPersona" id="IDPersona" value= "<?php echo e($persona->IDPersona); ?>" />
        </div>
      </form>
    </div>
    <div class="col s12 m4 l2"></div>
</div>

<script>

  window.onload = function() {
    
      $(document).ready(function(){
        $('#parroquia > option[value="<?php echo e($acta->IDParroquia); ?>"]').attr('selected', 'selected');
        $("input[name=tipoHijo][value= <?php echo e($laico->IDTipo_Hijo); ?> ]").prop('checked', true);
      });
  
      $("#tipoH2").change(function() {  
          if($("#tipoH2").is(':checked')) {  
              $("#nombrePadreEdit").prop('disabled', false); 
              $("#nombreMadreEdit").prop('disabled', false);
          }  
      });
      
      $("#tipoH1").change(function() {  
          if($("#tipoH1").is(':checked')) {  
              $("#nombrePadreEdit").prop('disabled', true);
              $("#nombreMadreEdit").prop('disabled', false);
          }  
      });
      
      $("#checkBautismo").change(function() {  
        if($("#checkBautismo").is(':checked')) {  
            $("#contentBautismo").css("display", "block");
        }else {
            $("#contentBautismo").css("display", "none");
        }  
      });
      
      $("#checkConfirma").change(function() {  
        if($("#checkConfirma").is(':checked')) {  
            $("#contentConfirma").css("display", "block");
        }else {
            $("#contentConfirma").css("display", "none");
        }  
      });
      
      $("#checkMatrimonio").change(function() {  
        if($("#checkMatrimonio").is(':checked')) {  
            $("#contentMatrimonio").css("display", "block");
        }else {
            $("#contentMatrimonio").css("display", "none");
        }  
      });
      
      $("#checkDefuncion").change(function() {  
        if($("#checkDefuncion").is(':checked')) {  
            $("#contentDefuncion").css("display", "block");
        }else {
            $("#contentDefuncion").css("display", "none");
        }  
      });
  
      $('select').material_select();
  
  }

</script>

<?php $__env->stopSection(); ?>         
              
<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>