<?php $__env->startSection('content'); ?>

<style type="text/css">
  body {
    background-color: #fff3e0;
}
</style>

<div class="row">
    <div class="col s12 m4 l2"></div>
    <div class=" col s12 m4 l8 card-panel z-depth-5">

        <div class="row">
          <div class="col s12 m4 l4"></div>
          
          <div class="col s12 m4 l4"><h4><blockquote class="center-align">Nueva Acta</blockquote></h4></div>
          
          <div class="col s12 m4 l4"></div>
        </div>
        <form>
            <div class="row">
                <div class="input-field col s6">
                  <input id="numCedula" type="text" class="validate">
                  <label for="numCedula">Numero de cedula:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s4">
                  <input id="nombre" type="text" class="validate">
                  <label for="nombre">Nombre:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido1" type="text" class="validate">
                  <label for="apellido1">Primer apellido:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido2" type="text" class="validate">
                  <label for="apellido2">Segundo apellido:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s4">
                    <p>
                      <input name="group1" type="radio" id="tipoH1" />
                      <label for="tipoH1">Hijo Natural</label>
                    </p>
                    <p>
                      <input name="group1" type="radio" id="tipoH2" />
                      <label for="tipoH2">Hijo Legitimo</label>
                    </p>
                </div>
                <div class="col s8">
                  <div class="row">
                    <div class="input-field col s12">
                      <input id="nombreMadre" type="text" class="validate">
                      <label for="nombreMadre">Nombre completo de la madre:</label>
                    </div>
                  </div>
                  <div class="row">
                    <div class="input-field col s12">
                      <input id="nombrePadre" type="text" class="validate">
                      <label for="nombrePadre">Nombre completo del padre:</label>
                    </div>
                  </div>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                  <input id="lugarNac" type="text" class="validate">
                  <label for="LugarNac">Lugar de nacimiento:</label>
                </div>
                <div class="input-field col s6">
                  <input id="fechaNac" type="date" class="datepicker">
                  <label for="fechaNac">Fecha de nacimiento:</label>
                </div>
            </div>
            <div class="row">
                <input id="guardarPersona" class="waves-effect waves-light btn right" type="submit" value="Guardar"/>
            </div>
        </form>
        
        <div class="row"></br></br></div>
        
        <div class="row">
            
            <ul class="collapsible" data-collapsible="accordion">
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Bautismo</div>
                  <div class="collapsible-body">
                      
                      <form>
            <div class="row">
                <div class="input-field col s6">
                  <input id="numCedula" type="text" class="validate">
                  <label for="numCedula">Numero de cedula:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s4">
                  <input id="nombre" type="text" class="validate">
                  <label for="nombre">Nombre:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido1" type="text" class="validate">
                  <label for="apellido1">Primer apellido:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido2" type="text" class="validate">
                  <label for="apellido2">Segundo apellido:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s4">
                    <p>
                      <input name="group1" type="radio" id="tipoH1" />
                      <label for="tipoH1">Hijo Natural</label>
                    </p>
                    <p>
                      <input name="group1" type="radio" id="tipoH2" />
                      <label for="tipoH2">Hijo Legitimo</label>
                    </p>
                </div>
                <div class="input-field col s8">
                  <input id="nombreMadre" type="text" class="validate">
                  <label for="nombreMadre">Nombre completo de la madre:</label>
                </div>
            </div>
            <div class="row">
                <div class="input-field col s6">
                  <input id="lugarNac" type="text" class="validate">
                  <label for="LugarNac">Lugar de nacimiento:</label>
                </div>
                <div class="input-field col s6">
                  <input id="fechaNac" type="date" class="datepicker">
                  <label for="fechaNac">Fecha de nacimiento:</label>
                </div>
            </div>
            <div class="row">
                <input id="guardarPersona" class="waves-effect waves-light btn right" type="submit" value="Guardar"/>
            </div>
        </form>
                      
                  </div>
                </li>
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Confirma</div>
                  <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                </li>
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Matrimonio</div>
                  <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                </li>
                <li>
                  <div class="collapsible-header waves-light waves-effect teal lighten-1">Acta de Defuncion</div>
                  <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>
                </li>
            </ul>
            
        </div>
    </div>
    <div class="col s12 m4 l2"></div>
</div>

<a class="waves-effect waves-light btn"><i class="material-icons right">cloud</i>button</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>