<?php $__env->startSection('content'); ?>
    <div class="row">
        <br>
    <?php if(session()->has('msjMalo')): ?>
        <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel red lighten-2 center-align">
              <span class="white-text"><?php echo e(session('msjMalo')); ?></span>
            </div>
          </div>
          <div class="col l2"></div><br><br><br><br><br>
    <?php endif; ?>
    
    <?php if(session()->has('msjBueno')): ?>
        <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel green darken-3 center-align">
              <span class="white-text"><?php echo e(session('msjBueno')); ?></span>
            </div>
          </div>
          <div class="col l2"></div><br><br><br><br><br>
    <?php endif; ?>
    
         <div class="col m3 l3"></div>
          <div class="col s16 m3 l6">
        <div class="card-panel z-depth-5">
            
            <h3 class="center-align">Editar información personal</h3>
                <br>
                
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" role="form" method="POST" action="/guardarPerfil">
                        <?php echo e(csrf_field()); ?>

                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Nombre</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(Auth::user()->Nombre); ?>" autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        
                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Primer Apellido</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="pApellido" value="<?php echo e(Auth::user()->PrimerApellido); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Segundo Apellido</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="sApellido" value="<?php echo e(Auth::user()->SegundoApellido); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                         <div class="input-field">
                          <select name='parroquia' id="parroquia">
                            <?php $__currentLoopData = $parroquias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($pa->IDParroquia); ?>"><?php echo e($pa->NombreParroquia); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <label>Parroquia</label>
                        </div>
                    
                        <div class="input-field">
                            <select name='idPuesto' id="idPuesto" readonly>
                                <option value="<?php echo e($puesto->IDPuesto); ?>"><?php echo e($puesto->NombrePuesto); ?></option>
                            </select>
                            <label>Puesto</label>
                        </div>

                         <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email" class="col-md-4 control-label">Correo electrónico</label>
                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" autofocus>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="cel" class="col-md-4 control-label">Número de celular</label>

                            <div class="col-md-6">
                                <input id="cel" type="text" class="form-control" name="numCel" value="<?php echo e(Auth::user()->NumCelular); ?>">
                            </div>
                        </div>


                        <div class="row">
                            <br>
                            <button id="guardarActa" class="waves-effect waves-light btn right" type="submit"><i class="material-icons left">save</i>Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
 
      window.onload = function() {
        
        $(document).ready(function(){
            $('#parroquia > option[value="<?php echo e(Auth::user()->IDParroquia); ?>"]').attr('selected', 'selected');
            $('#puesto > option[value="<?php echo e(Auth::user()->IDPuesto); ?>"]').attr('selected', 'selected');
            $('#rol > option[value="<?php echo e(Auth::user()->IDRol); ?>"]').attr('selected', 'selected');
        });
        
         $('select').material_select();
      
      }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>