<?php $__env->startSection('content'); ?>

    <style type="text/css">

        td, th {
            padding: 8px 5px;
            text-align: center;
        }

    </style>

    <div class="row" style="padding-left:1em;padding-right:1em">
        <?php if(session()->has('msjMalo')): ?>
            <div class="col l2"></div>
            <div class="col s12 m8 l8">
                <div class="card-panel red lighten-2 center-align">
                    <span class="white-text"><?php echo e(session('msjMalo')); ?></span>
                </div>
            </div>
            <div class="col l2"></div><br><br><br><br><br>
        <?php endif; ?>

        <?php if(session()->has('msjBueno')): ?>
            <div class="col l2"></div>
            <div class="col s12 m8 l8">
                <div class="card-panel green darken-3 center-align">
                    <span class="white-text"><?php echo e(session('msjBueno')); ?></span>
                </div>
            </div>
            <div class="col l2"></div><br><br><br><br><br>
        <?php endif; ?>

        <div class="col s12 m4 l3 card-panel z-depth-2">

            <form id="queryForm" method="POST">
                <?php echo e(csrf_field()); ?>


                <div class="row align-center"><h5>Criterios de búsqueda</h5></div>

                <div class="row">

                    <div class="col s12">
                        <p>
                            <input name="buscCed" type="checkbox" id="buscCed"/>
                            <label for="buscCed">Buscar por cédula</label>
                        </p>
                    </div>
                    <div class="input-field col s12">
                        <input placeholder="Número de Cédula" id="numCed" type="text" class="validate" minlength="9"
                               maxlength="9" required
                               oninvalid="this.setCustomValidity('Debe ingresar cedula con el formato: 101230456')"
                               oninput="setCustomValidity('')" name="numCed" disabled>
                    </div>
                </div>

                <div class="row">
                    <div class="input-field col s12">
                        <input name='nombre' id="nombre" type="text" class="validate">
                        <label for="nombre">Nombre:</label>
                    </div>

                    <div class="input-field col s12">
                        <select name="parroquia" id="parroquias">
                            <option value="">---</option>
                            <?php $__currentLoopData = $parroquias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pa->IDParroquia); ?>"><?php echo e($pa->NombreParroquia); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label>Seleccione la Parroquia:</label>
                    </div>

                    <div class="col s12">
                        <label>Busqueda por rango de fechas:</label>
                        <div class="input-field col s12">
                            <input id="fechaInicio" name="fechaInicio"
                                   pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d"
                                   class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa">
                            <label for="fechaInicio">Desde:</label>
                        </div>
                        <div class="input-field col s12">
                            <input id="fechaFin" name="fechaFin"
                                   pattern="(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)\d\d"
                                   class="datepicker" type="date" title="Formato de fecha: dd/mm/aaaa">
                            <label for="fechaFin">Hasta:</label>
                        </div>
                    </div>


                </div>

                <div class="row">
                    <button id="buscar" class="waves-effect waves-light btn right" type="submit"><i
                                class="material-icons left">search</i>Buscar
                    </button>
                </div>
            </form>

        </div>


        <div class="col s12 m4 l9 card-panel z-depth-2">


            <table id='tablaConsulta' class="bordered">
                <thead>
                <tr>
                    <th>Cédula</th>
                    <th>Nombre</th>
                    <th>Primer apellido</th>
                    <th>Segundo apellido</th>
                    <th>Detalle</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <script type="text/javascript">

        window.onload = function () {
            $('.datepicker').pickadate({
                format: 'dd/mm/yyyy',
                monthsFull: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
                monthsShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                weekdaysFull: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
                weekdaysShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
                selectMonths: true,
                selectYears: 300, // Puedes cambiarlo para mostrar más o menos años
                today: 'Hoy',
                clear: 'Limpiar',
                close: 'Ok',
                labelMonthNext: 'Siguiente mes',
                labelMonthPrev: 'Mes anterior',
                labelMonthSelect: 'Selecciona un mes',
                labelYearSelect: 'Selecciona un año',
                max: new Date(),
                autoClose: true,
                setDefaultDate: true,
                defaultDate: new Date()
            });

            $('select').material_select();

            $("#buscCed").change(function () {
                if ($("#buscCed").is(':checked')) {
                    $("#numCed").prop('disabled', false);
                    $("#nombre").prop('disabled', true);
                    $("#parroquias").prop('disabled', true);
                    $("#fechaInicio").prop('disabled', true);
                    $("#fechaFin").prop('disabled', true);

                    $('select').material_select();
                } else {
                    $('#queryForm').trigger("reset");
                    $("#numCed").prop('disabled', true);
                    $("#nombre").prop('disabled', false);
                    $("#parroquias").prop('disabled', false);
                    $("#fechaInicio").prop('disabled', false);
                    $("#fechaFin").prop('disabled', false);

                    $('select').material_select();
                }
            });

            $('#queryForm').on('submit', function (e) {
                e.preventDefault();

                $.ajax({
                    type: "POST",
                    url: "/queryPersonas",
                    data: $("#queryForm").serialize(), // serializes the form's elements.
                    success: function (data) {
                        $("#tablaConsulta td").parent().remove();

                        var len = data.length;
                        for (var i = 0; i < len; i++) {
                            var idPersona = data[i].IDPersona;
                            var cedula = data[i].persona.Cedula;
                            var nombre = data[i].persona.Nombre;
                            var primerApellido = data[i].persona.PrimerApellido;
                            var segundoApellido = data[i].persona.SegundoApellido;

                            var iconDetalle = "<i class='material-icons'>description</i>";
                            var detalle = "<a id='" + idPersona + "Detalle'>" + iconDetalle + "</a>";

                            var iconEditar = "<i class='material-icons'>mode_edit</i>";
                            var editar = "<a id='" + idPersona + "Editar'>" + iconEditar + "</a>";

                            var iconEliminar = "<i class='material-icons'>delete</i>";
                            var eliminar = "<a id='" + idPersona + "Eliminar'>" + iconEliminar + "</a>";

                            $('#tablaConsulta tbody').append('<tr><td>' + cedula + '</td><td>' + nombre + '</td><td>' + primerApellido + '</td><td>'
                                + segundoApellido + '</td><td>' + detalle + '</td><td>' + editar + '</td><td>' + eliminar + '</td></tr>');


                            document.getElementById(idPersona + "Editar").setAttribute('href', window.location.origin + '/Editar' + idPersona);
                            document.getElementById(idPersona + "Eliminar").setAttribute('href', window.location.origin + '/Eliminar' + idPersona);
                            document.getElementById(idPersona + "Detalle").setAttribute('href', window.location.origin + '/Detalle' + idPersona);


                        }
                    }
                });
            });
        };
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>