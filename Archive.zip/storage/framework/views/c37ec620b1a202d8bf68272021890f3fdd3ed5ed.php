<?php $__env->startSection('content'); ?>


<div class="row">
    <br>
    <?php if(Session::has('errorLogin')): ?>
            <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel red lighten-2 center-align">
              <span class="white-text"><?php echo e(Session::get('errorLogin')); ?></span>
            </div>
          </div>
          <div class="col l2"></div>
    <?php endif; ?>
    
    <?php if(Session::has('justLogin')): ?>
            <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel green darken-3 center-align">
              <span class="white-text"><?php echo e(Session::get('justLogin')); ?></span>
            </div>
          </div>
          <div class="col l2"></div>
    <?php endif; ?>
    
      <div class="col m3 l4"></div>
      <div class="col s12 m3 l4">
        <div class="card-panel z-depth-4">
            
            <h3 class="center-align">Iniciar Sesión</h3>
          <br>
          <form class="form-horizontal" role="form" method="POST" action="/loginn">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">Correo electrónico</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Contraseña</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-12 col-md-offset-4">
                                <button type="submit" class="waves-effect waves-light btn">
                                    Login
                                </button>

                                <a class="btn-link right" href="<?php echo e(url('emailRecuperacion')); ?>">
                                    ¿Olvidó su contraseña?
                                </a>
                            </div>
                        </div>
                    </form>
          
        </div>
      </div>
      <div class="col m3 l4"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>