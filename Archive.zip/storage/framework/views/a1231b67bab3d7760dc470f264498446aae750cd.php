<!DOCTYPE html>
<html>
    
     <div class="row">
                <div class="input-field col s6">
                  <input id="numCedulaEdit" name='numCedulaEdit' type="text" class="validate" value=" sss"  maxlength="9">
                  <label for="numCedulaEdit">Número de cédula:</label>
                </div>
                
               
          
            
            
                
                
                <div class="input-field col s4">
                  <input id="apellido1Edit" name='apellido1Edit' type="text"  value=" Anchia ">
                  <label for="apellido1Edit">Primer apellido:</label>
                </div>
                <div class="input-field col s4">
                  <input id="apellido2Edit" name='apellido2Edit' value="Perez">
                  <label for="apellido2Edit">Segundo apellido:</label value="Perez" >
                </div>
            </div>
                   
</html>
 
          
            
                   