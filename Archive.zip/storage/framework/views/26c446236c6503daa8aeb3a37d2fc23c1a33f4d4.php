<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <br>
      <div class="col m3 l4"></div>
      <div class="col s12 m3 l4">
        <div class="card-panel z-depth-4">
            <div class="panel-heading">Cambiar contraseña</div>
             <br>
             <form class="form-horizontal" role="form" >
                <div class="form-group">
                     <label class="col-md-4 control-label" for="contrasena">Contraseña actual </label>
                     <div class="col-md-6">
                        <input class="form-control" type="password" name="contrasenaActual" id="contrasenaActual" required autofocus>
                     </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label" for="contrasena">Nueva contraseña </label>
                      <div class="col-md-6">
                          <input class="form-control" type="password" name="contrasena" id="contrasena" required autofocus>
                      </div>
                  </div>
                 
                  <div class="form-group">
                      <label class="col-md-4 control-label" for="contrasena2">Confirmar contraseña </label>
                      <div class="col-md-6">
                          <input class="form-control" type="password" name="contrasena2" id="contrasena2" required autofocus>
                      </div>
                  </div>
                  
                  <div class="form-group">
                        <div class="col-md-6 col-md-offset-6">
                            <button type="submit" class="btn btn-primary">
                                Cambiar contraseña
                            </button>
                        </div>
                  </div> 
                        <input type="hidden" name="id" id="id" value= "<?php echo e(Auth::user()->id); ?>" />
             </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>