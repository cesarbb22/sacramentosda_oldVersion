
<!DOCTYPE html>
<html>
    
    <head>
        <title>Certificado Sacramentos Recibidos <title>
            <link rel="stylesheet" href="css/pdf.css" type="text/css" />
        
    </head>
    <body>
        <div class = "divimagdioce">
            <img src="style/img/dioce3.PNG"></img>
        </div>
        <div class= "divtitulo">
            <h4>Archivo Histórico de la Curia de Alajuela  <br/> Constancia de Sacramentos Recibidos </h4>
        </div>
        <div class = "divimagcuria"> 
        <img src="style/img/curia3.PNG"></img>
        </div>
        
        
        <div class="container">
        <div class ="divParrafo">
        <p>El suscrito Pbro.Sixto Edo. Varela Santamaría, Canciller de la Curia Diocesana de Alajuela; <br/>
        Certifica que en los libros sacramentales custodiados en el Archivo Histórico se encuentra la siguiente información:</p>
        </div>
        
                    
        
      
        <div class= "Divpersona" style="border-bottom: 2px solid;">
        <label for="idParroqui"><b> En la Parroquia de: </b>   <?php echo e(Auth::user()->parroquia->NombreParroquia); ?></label>  <br/>
        <label for="persona"><b>Se encuentra la información de: </b><?php echo e($personaNom); ?> <?php echo e($personaAp1); ?> <?php echo e($personaAp2); ?></label>   <br/>
        <label for="cedula"> <b>Cédula de identidad: </b>  <?php echo e($numCedulaEdit); ?></label><br/>
          <?php if($tipoHijo == 1 ): ?>
          <label for="Hij(o)1"><b> Hij(o): </b> Natural </label>
          <?php else: ?>
           <label for="Hij(o)2"><b> Hij(o): </b>Legítimo </label>
          <?php endif; ?>
        <label for="de"> <b>de: </b><?php echo e($personamadre); ?> <?php echo e($personaPadre); ?></label>  <br/>
        <label for="Nacido"> <b>Nacido en: </b> <?php echo e($nacidolugar); ?>  </label> <br/>
        <label for="día"><b>El día: </b> <?php echo e($fechaNacEdit); ?>  </label><br/>
       
        </div>
        <?php if($lugarBautizado != null ): ?>
        <div class="DivBautizo" style="border-bottom: 2px solid;">
             
            <label for="BAUTIZADO"><b>BAUTIZADO EN: </b>  <?php echo e($lugarBautizado); ?></label> <br/>
             <label for="díaB"><b>El día: </b> <?php echo e($fechaBau); ?></label><br/>
            <label for="Padrinos"><b>Padrinos: </b> <?php echo e($nombreMadrinaB); ?> <?php echo e($nombrePadrinoB); ?> </label> <br/>
            <label for="InfoB"><b>Esta Información consta en el Libro: </b> <?php echo e($numLibroB); ?></label><label for="FolioB">   <b>Folio: </b> <?php echo e($numFolioB); ?></label><label for="AsientoB">     <b>Asiento: </b>  <?php echo e($numAsientoB); ?></label><br/>
        </div>
           <?php else: ?>
                    <div class="Nobautizo">
                  <label for="BAUTIZADO"><b>BAUTIZADO EN: </b>  No cuenta con esta acta</label> <br/>
                        
                    </div>
                    
                <?php endif; ?>
        
         <?php if($lugarConfirma != null ): ?>
        <div class = "DivConfirma" style="border-bottom: 2px solid;">
            <label><b>CONFIRMADO EN: </b><?php echo e($lugarConfirma); ?></label><br/>
            <label><b>El día: </b><?php echo e($fechaConfirma); ?></label><br/>
            <label><b>Padrinos: </b> <?php echo e($nombrePadrinoC1); ?> <?php echo e($nombrePadrinoC2); ?></label><br/>
            <label><b>Esta Información consta en el Libro: </b> <?php echo e($numLibroC); ?></label> <label>   <b>Folio: </b <?php echo e($numFolioC); ?></label> <label>   <b>Asiento: </b><?php echo e($numAsientoC); ?></label><br/>
        </div>
        <?php else: ?>
                <div class="Noconfirma">
                  <label><b>CONFIRMADO EN: </b>  No cuenta con esta acta</label> <br/>
                </div>
                    
                <?php endif; ?>
                
        <?php if($lugarMatrimonio != null ): ?>  
        <div class= "DivMatrimonio" style="border-bottom: 2px solid;">
            <label><b>MATRIMONIO EN: </b><?php echo e($lugarMatrimonio); ?></label> <br/>
            <label><b>Con: </b><?php echo e($nombreConyuge); ?> </label><br/>
            <label><b>El día: </b><?php echo e($fechaMatrimonio); ?></label><br/>
            <label><b>Esta Información consta en el Libro: </b><?php echo e($numLibroM); ?> </label> <label>  <b>Folio: </b> <?php echo e($numFolioM); ?></label> <label>    <b>Asiento: </b><?php echo e($numAsientoM); ?></label><br/>
        </div>
         <?php else: ?>
                <div class="NoMatrimonio">
                 <label><b>MATRIMONIO EN: </b> No cuenta con esta acta</label> <br/>
                </div>
                    
         <?php endif; ?>
        
        <?php if($lugarDefuncion != null ): ?> 
        <div class= "divdefun" style="border-bottom: 2px solid;" >
            <label for="DEFUNCION"><b>DEFUNCIÓN EN: </b>  <?php echo e($lugarDefuncion); ?></label> <br/>
            <label for="díaD"><b>El día: </b> <?php echo e($fechaDefuncion); ?></label><br/>
            <label><b>A causa de: </b> <?php echo e($causaDefuncion); ?></label><br/>
            <label><b>Esta Información consta en el Libro: </b> <?php echo e($numLibroD); ?></label> <label>   <b>Folio: </b> <?php echo e($numFolioD); ?></label> <label>   <b>Asiento: </b><?php echo e($numAsientoD); ?></label><br/>
        </div
         <?php else: ?>
                <div class="NoDefuncion">
               <label for="DEFUNCION"><b>DEFUNCIÓN EN: </b> No cuenta con esta acta</label> <br/>
                </div>
                    
         <?php endif; ?>
         <?php if($notasMarginalesEdit != null ): ?> 
        <div class="divNotas" >
            <label for="notasMarginales"><b>Notas Marginales: </b>  <?php echo e($notasMarginalesEdit); ?></label><br/>
            
        </div>
          <?php else: ?>
                <div class="NoNotas">
               <label for="notasMarginales"><b>Notas Marginales: </b> No cuenta con ninguna nota</label> <br/>
                </div>
                    
         <?php endif; ?>
        
       </div>
    </body>
</html>
        
     
      

      
      
      