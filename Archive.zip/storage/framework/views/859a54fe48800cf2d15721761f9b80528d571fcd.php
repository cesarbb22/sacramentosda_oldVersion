<?php $__env->startSection('content'); ?>

<style type="text/css">
#n {
  padding-top:5px;
}

</style>

 <div id='n' class="row">
    <div class="col s12 m4 l2"></div>
    <div class=" col s12 m4 l8 card-panel z-depth-5">

        <table class="bordered">
            <thead>
                <tr>
                    <th>Cédula</th>
                    <th>Nombre</th>
                    <th>Primer apellido</th>
                    <th>Segundo apellido</th>
                    <th>Operación</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($persona->Cedula); ?></td>
                    <td><?php echo e($persona->Nombre); ?></td>
                    <td><?php echo e($persona->PrimerApellido); ?></td>
                    <td><?php echo e($persona->SegundoApellido); ?></td>
                    <td>
                        <a href="<?php echo e(route('/Editar', $persona->IDPersona)); ?>" class="btn btn-primary">
                        Editar
                        </a> <a href="<?php echo e(route('/Eliminar', $persona->IDPersona)); ?>" class="btn btn-primary">
                        Eliminar
                        </a>
                    </td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>