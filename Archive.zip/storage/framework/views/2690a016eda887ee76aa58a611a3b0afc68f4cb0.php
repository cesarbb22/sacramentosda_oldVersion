<?php $__env->startSection('content'); ?>
<div id='n' class="row">
    <?php if(session()->has('msjMalo')): ?>
        <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel red lighten-2 center-align">
              <span class="white-text"><?php echo e(session('msjMalo')); ?></span>
            </div>
          </div>
          <div class="col l2"></div><br><br><br><br><br>
    <?php endif; ?>
    
    <?php if(session()->has('msjBueno')): ?>
        <div class="col l2"></div>
          <div class="col s12 m8 l8">
            <div class="card-panel green darken-3 center-align">
              <span class="white-text"><?php echo e(session('msjBueno')); ?></span>
            </div>
          </div>
          <div class="col l2"></div><br><br><br><br><br>
    <?php endif; ?>
  
    <div class="col s12 m4 l2"></div>
    <div class="col s12 m4 l8 card-panel z-depth-2">

        <div class="row">
          <div class="col s12 m4 l2"></div>
          <div class="col s12 m4 l8"><h4 class="center-align">Mantenimiento Usuarios</h4></div>
          <div class="col s12 m4 l2"></div>
        </div>
        
      <?php if(count($errors) > 0): ?>
        <div class="row">
          <div class="col s12">
            <div class="card-panel red">
              <ul class='white-text'>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      <?php endif; ?>
        
      <form method="POST" action="/">
            
          <?php echo e(csrf_field()); ?>


      
        <table id='tablaConsulta' class="bordered centered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Primer apellido</th>
                    <th>Segundo apellido</th>
                    <th>Email</th>
                    <th>Editar</th>

                </tr>
            </thead>
            
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody>
                    <td><?php echo e($usuario->Nombre); ?></td>
                    <td><?php echo e($usuario->PrimerApellido); ?></td>
                    <td><?php echo e($usuario->SegundoApellido); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><a href="<?php echo e(route('/EditarUsuario', $usuario->IDUser)); ?>"><i class='material-icons'>mode_edit</i></a></td>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        
         <div class="row">
          <br>
          <button id="nuevoUser" class="waves-effect waves-light btn right" type="submit"><a class="white-text" href="<?php echo e(url('agregarUsuario')); ?>"><i class="material-icons left">add</i>Nuevo Usuario</a></button>
        </div>
        
      </form>
    </div>
    <div class="col s12 m4 l2"></div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>