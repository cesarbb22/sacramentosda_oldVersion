<?php $__env->startSection('content'); ?>
    <div class="row">
        <br>
         <div class="col m3 l3"></div>
         <div class="col s16 m3 l6">
        <div class="card-panel z-depth-5">
            
            <h3 class="center-align">Restablecer contraseña</h3>
                <br>
        
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="input-field<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email">Correo electrónico</label>
                            <input id="email" type="email" class="validate" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                        
                        <div class="row">
                            <br>
                            <button type="submit" class="waves-effect waves-light btn right">
                                Enviar Link
                            </button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masterPageAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>